package readiefur.misc;

public interface IDisposable
{
    Boolean isDisposed = false;
    void Dispose();
}
