package readiefur.xml_ui.controls;
// package xml_ui.controls;

// import java.awt.Color;
// import java.util.function.Consumer;

// import javax.swing.JRadioButton;

// import xml_ui.attributes.EventAttribute;
// import xml_ui.attributes.SetterAttribute;

// public class RadioButton extends JRadioButton
// {
//     public RadioButton()
//     {
//         super();
//     }

//     @SetterAttribute("Text")
//     public void SetText(String text)
//     {
//         setText(text);
//     }

//     @SetterAttribute("ToolTip")
//     public void SetToolTip(String toolTip)
//     {
//         setToolTipText(toolTip);
//     }

//     @SetterAttribute("Checked")
//     public void SetChecked(String checked)
//     {
//         setSelected(Boolean.parseBoolean(checked));
//     }

//     @EventAttribute("Click")
//     public void SetClick(Consumer<Object[]> callback)
//     {
//         addActionListener(e -> callback.accept(new Object[]{}));
//     }
// }
