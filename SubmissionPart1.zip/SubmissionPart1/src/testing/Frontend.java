package testing;

import org.junit.Test;

import readiefur.console.ELogLevel;
import readiefur.console.Logger;

public class Frontend
{
    public Frontend()
    {
        Logger.logLevel = ELogLevel.TRACE;
    }
}
