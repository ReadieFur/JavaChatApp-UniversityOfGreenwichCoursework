package chat_app.backend.net_data;

import java.io.Serializable;

/**
 * An empty payload for network messages that do not require a payload.
 */
public class EmptyPayload implements Serializable {}
