Below are a list of the libraries this project requires, currently they are only needed for unit testing.  
You can either download them manually or run the `Install.bat` file to download them automatically.

| Library | Description |
| --- | --- |
| [JUnit](https://repo1.maven.org/maven2/junit/junit/4.13.2/junit-4.13.2.jar) | Used for unit testing. |
| [Hamcrest](https://repo1.maven.org/maven2/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar) | Dependency for JUnit. |
